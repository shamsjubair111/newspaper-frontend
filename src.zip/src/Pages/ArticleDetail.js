import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import './ArticleDetail.css';

const ArticleDetail = () => {
  const { id } = useParams();
  const [article, setArticle] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchArticle = async () => {
      try {
        setLoading(true);
        const response = await fetch(`${process.env.REACT_APP_API_URL}/api/articles/${id}`);
        
        if (!response.ok) {
          throw new Error('Article not found');
        }
        
        const data = await response.json();
        setArticle(data);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchArticle();
  }, [id]);

  // Format date and time in Bengali
  const formatDateTimeBengali = (dateString) => {
    const date = new Date(dateString);
    const months = ['জানুয়ারি', 'ফেব্রুয়ারি', 'মার্চ', 'এপ্রিল', 'মে', 'জুন', 'জুলাই', 'আগস্ট', 'সেপ্টেম্বর', 'অক্টোবর', 'নভেম্বর', 'ডিসেম্বর'];
    const bengaliNumerals = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
    
    const day = date.getDate().toString().split('').map(d => bengaliNumerals[parseInt(d)]).join('');
    const month = months[date.getMonth()];
    const year = date.getFullYear().toString().split('').map(d => bengaliNumerals[parseInt(d)]).join('');
    const hours = date.getHours().toString().padStart(2, '0').split('').map(d => bengaliNumerals[parseInt(d)]).join('');
    const minutes = date.getMinutes().toString().padStart(2, '0').split('').map(d => bengaliNumerals[parseInt(d)]).join('');
    
    return `আপডেট: ${day} ${month} ${year}, ${hours}: ${minutes}`;
  };

  if (loading) {
    return (
      <div className="article-detail-loading">
        <div className="container py-5 text-center">
          <div className="spinner-border text-primary" role="status">
            <span className="visually-hidden">Loading...</span>
          </div>
        </div>
      </div>
    );
  }

  if (error || !article) {
    return (
      <div className="article-detail-error">
        <div className="container py-5 text-center">
          <h2 className="text-danger mb-3">Article not found</h2>
          <Link to="/" className="btn btn-primary">Go to Home</Link>
        </div>
      </div>
    );
  }

  return (
    <div className="article-detail">
      <div className="container">
        <article className="article-content">
          {/* Category Breadcrumb */}
          <div className="article-breadcrumb">
            <Link to="/" className="breadcrumb-home">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                <path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"/>
              </svg>
            </Link>
            {article.category?.name && (
              <Link to={`/category/${article.category._id}`} className="breadcrumb-category">
                {article.category.name}
              </Link>
            )}
          </div>

          {/* Article Title */}
          <h1 className="article-title">{article.title}</h1>

          {/* Article Meta */}
          <div className="article-meta">
            {article.author?.name && (
              <div className="article-author">
                <span className="meta-label">লেখা:</span>
                <span className="meta-value">{article.author.name}</span>
              </div>
            )}
            <div className="article-date">
              {formatDateTimeBengali(article.updatedAt || article.createdAt)}
            </div>
          </div>

          {/* Article Summary (if exists) */}
          {article.summary && (
            <div className="article-summary-box">
              <strong className="summary-label">সারকথা</strong>
              <p className="summary-text">{article.summary}</p>
            </div>
          )}

          {/* Article Content */}
          <div 
            className="article-body" 
            dangerouslySetInnerHTML={{ __html: article.content }}
          />

          {/* Article Footer */}
          <div className="article-footer">
            <div className="article-tags">
              {article.category?.name && (
                <Link to={`/category/${article.category._id}`} className="tag">
                  {article.category.name}
                </Link>
              )}
              {article.subcategory?.name && (
                <Link to={`/subcategory/${article.subcategory._id}`} className="tag">
                  {article.subcategory.name}
                </Link>
              )}
            </div>
          </div>
        </article>
      </div>
    </div>
  );
};

export default ArticleDetail;